<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <!-- Add your HTML head content here (e.g., stylesheets, scripts) -->
</head>
<body>
    <h1>Manage Users</h1>

    <!-- Display a list of users from your database -->
    <table>
        <thead>
            <tr>
                <th>User ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <!-- Loop through users and display their information -->
            
    <a href="caradmin_dashboard.php">Back to Dashboard</a>
</body>
</html>
